package com.edits.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Template(
    val title: String,
    val category: String,
    val duration: String,
    val mediaCount: Int
)

val templates = listOf(
    Template("Beat Drop", "Trending", "00:12", 8),
    Template("Golden Memories", "Love", "00:15", 10),
    Template("Birthday Vibes", "Birthday", "00:18", 12),
    Template("Velocity Flow", "Beat", "00:10", 7),
    Template("Photo Motion", "Photo", "00:14", 9),
    Template("Dark Energy", "Trending", "00:11", 6),
    Template("Summer Trip", "Travel", "00:20", 14),
    Template("Best Friends", "Love", "00:16", 11)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EditsApp() }
    }
}

@Composable
fun EditsApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedTemplate by remember { mutableStateOf<Template?>(null) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF09090B),
            surface = Color(0xFF121216),
            primary = Color(0xFFB7FF2A)
        )
    ) {
        if (selectedTemplate != null) {
            EditorScreen(
                template = selectedTemplate!!,
                onBack = { selectedTemplate = null }
            )
        } else {
            Scaffold(
                containerColor = Color(0xFF09090B),
                bottomBar = {
                    NavigationBar(containerColor = Color(0xFF111114)) {
                        NavigationBarItem(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            icon = { Icon(Icons.Default.Home, null) },
                            label = { Text("Home") }
                        )
                        NavigationBarItem(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            icon = { Icon(Icons.Default.VideoLibrary, null) },
                            label = { Text("Templates") }
                        )
                        NavigationBarItem(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            icon = { Icon(Icons.Default.Person, null) },
                            label = { Text("Profile") }
                        )
                    }
                },
                floatingActionButton = {
                    FloatingActionButton(
                        onClick = { selectedTemplate = Template("New Project", "Custom", "00:00", 0) },
                        containerColor = Color(0xFFB7FF2A),
                        contentColor = Color.Black
                    ) { Icon(Icons.Default.Add, "New project") }
                }
            ) { padding ->
                when (selectedTab) {
                    0 -> HomeScreen(padding) { selectedTemplate = it }
                    1 -> TemplatesScreen(padding) { selectedTemplate = it }
                    else -> ProfileScreen(padding)
                }
            }
        }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, open: (Template) -> Unit) {
    Column(
        Modifier.padding(padding).padding(18.dp).fillMaxSize()
    ) {
        Text("Edits", fontSize = 34.sp, fontWeight = FontWeight.Bold)
        Text("Create. Edit. Share.", color = Color.Gray)

        Spacer(Modifier.height(26.dp))

        OutlinedTextField(
            value = "",
            onValueChange = {},
            enabled = false,
            placeholder = { Text("Search templates") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp)
        )

        Spacer(Modifier.height(24.dp))
        Text("Trending Templates", fontSize = 21.sp, fontWeight = FontWeight.Bold)

        Spacer(Modifier.height(12.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(templates.take(5)) { TemplateCard(it, open) }
        }

        Spacer(Modifier.height(26.dp))
        Text("Quick Start", fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickButton("New Project", Icons.Default.Add)
            QuickButton("My Templates", Icons.Default.FavoriteBorder)
        }
    }
}

@Composable
fun TemplatesScreen(padding: PaddingValues, open: (Template) -> Unit) {
    Column(Modifier.padding(padding).padding(18.dp)) {
        Text("Templates", fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        val categories = listOf("All", "Trending", "Beat", "Love", "Birthday", "Travel")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(categories) { Text(it, Modifier.background(Color(0xFF1A1A1F), RoundedCornerShape(20.dp)).padding(14.dp, 8.dp)) }
        }

        Spacer(Modifier.height(18.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(templates) { TemplateCard(it, open) }
        }
    }
}

@Composable
fun TemplateCard(template: Template, open: (Template) -> Unit) {
    Card(
        modifier = Modifier.width(180.dp).clickable { open(template) },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151519)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column {
            Box(
                Modifier.fillMaxWidth().height(150.dp).background(Color(0xFF24242A)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(48.dp))
                Text(template.duration, Modifier.align(Alignment.BottomEnd).padding(8.dp))
            }
            Column(Modifier.padding(12.dp)) {
                Text(template.title, fontWeight = FontWeight.Bold)
                Text("${template.mediaCount} clips • ${template.category}", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun QuickButton(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(
        modifier = Modifier.width(155.dp).height(90.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151519))
    ) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.Center) {
            Icon(icon, null)
            Text(title, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun EditorScreen(template: Template, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Color(0xFF09090B))) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("‹", fontSize = 34.sp, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(12.dp))
            Text(template.title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Box(
            Modifier.fillMaxWidth().weight(1f).padding(18.dp)
                .background(Color(0xFF202025), RoundedCornerShape(18.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.PlayArrow, null, Modifier.size(70.dp))
        }

        Text("Timeline", Modifier.padding(18.dp), fontSize = 18.sp, fontWeight = FontWeight.Bold)

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            EditorTool("Media")
            EditorTool("Text")
            EditorTool("Audio")
            EditorTool("Filters")
            EditorTool("Speed")
        }

        Button(
            onClick = {},
            modifier = Modifier.fillMaxWidth().padding(18.dp).height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB7FF2A), contentColor = Color.Black)
        ) {
            Text("Export Video", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun EditorTool(name: String) {
    Box(
        Modifier.background(Color(0xFF17171B), RoundedCornerShape(12.dp)).padding(14.dp, 10.dp)
    ) { Text(name, fontSize = 12.sp) }
}

@Composable
fun ProfileScreen(padding: PaddingValues) {
    Column(
        Modifier.padding(padding).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(30.dp))
        Icon(Icons.Default.Person, null, Modifier.size(80.dp))
        Text("Edits Creator", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Your projects & templates", color = Color.Gray)
    }
}
